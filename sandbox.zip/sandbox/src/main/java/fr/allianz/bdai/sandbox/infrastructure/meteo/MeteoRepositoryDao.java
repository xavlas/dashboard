package fr.allianz.bdai.sandbox.infrastructure.meteo;

import org.springframework.stereotype.Service;

public interface MeteoRepositoryDao {
    String getTemperature();
}
