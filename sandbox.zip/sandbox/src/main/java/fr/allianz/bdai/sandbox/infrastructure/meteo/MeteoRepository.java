package fr.allianz.bdai.sandbox.infrastructure.meteo;

public interface MeteoRepository {
    String getCurrentTemperature();
}
