package fr.allianz.bdai.sandbox.infrastructure.meteo;

import lombok.Data;

@Data
public class OpenWeatherResponse {
    String body;
}
