package fr.allianz.bdai.sandbox.infrastructure.meteo;

import org.springframework.stereotype.Service;

@Service
public class MeteoTemperatureDaoImpl implements MeteoRepositoryDao{

    @Override
    public String getTemperature() {
        return null;
    }
}
