package fr.allianz.bdai.sandbox.domain.banking;

public interface BankDao {
    String findby();
}
