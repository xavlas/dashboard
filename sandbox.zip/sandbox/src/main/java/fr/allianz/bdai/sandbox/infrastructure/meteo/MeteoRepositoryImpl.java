package fr.allianz.bdai.sandbox.infrastructure.meteo;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;


@Service
public class MeteoRepositoryImpl implements MeteoRepository {

    @Override
    public String getCurrentTemperature() {

        RestTemplate restTemplate = new RestTemplate();

        String fooResourceUrl
                = "https://api.openweathermap.org/data/2.5/weather?q=Paris&appid=0b545af03efb9154273367ce5a8cf834&units=metric";
        ResponseEntity<OpenWeatherResponse> response = restTemplate
                .getForEntity(fooResourceUrl, OpenWeatherResponse.class);

        var foo = response.getBody();


        return "26";
    }
}
