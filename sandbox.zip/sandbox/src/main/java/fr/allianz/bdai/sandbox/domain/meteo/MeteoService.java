package fr.allianz.bdai.sandbox.domain.meteo;

public interface MeteoService {
    String getCurrentTemperature();
}
