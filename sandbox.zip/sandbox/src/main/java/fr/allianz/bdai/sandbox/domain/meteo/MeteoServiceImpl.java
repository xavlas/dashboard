package fr.allianz.bdai.sandbox.domain.meteo;

import fr.allianz.bdai.sandbox.infrastructure.meteo.MeteoRepository;

public class MeteoServiceImpl implements MeteoService{

    private MeteoRepository meteoRepository;

    public MeteoServiceImpl(MeteoRepository meteoRepository) {
        this.meteoRepository = meteoRepository;
    }

    @Override
    public String getCurrentTemperature() {
        return this.meteoRepository.getCurrentTemperature();
    }
}
