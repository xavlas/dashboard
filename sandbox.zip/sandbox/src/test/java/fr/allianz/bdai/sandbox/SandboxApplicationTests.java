package fr.allianz.bdai.sandbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SandboxApplicationTests {

	@Test
	void contextLoads() {
	}

}
