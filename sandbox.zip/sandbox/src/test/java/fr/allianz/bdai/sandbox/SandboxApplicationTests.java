package fr.allianz.bdai.sandbox;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SandboxApplicationTests {

	public static void main(String[] args) {
		System.setProperty("spring.profiles.active", "test");
		SandboxApplication.main(args);
	}

}
