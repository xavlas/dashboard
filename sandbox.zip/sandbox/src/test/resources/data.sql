insert into ask_sandbox (id, create_date, room, temperature, humidity)
values ('20505720-416c-4420-bfc7-8ca6ddfae650',
        '2020-01-20 16:10:25', 'Salon', 25, 75),
       ('20505720-416c-4420-bfc7-8ca6ddfae655',
        '2020-01-20 16:10:25', 'Chambre', 28, 98);

